function showStartMenu() {
	//if(main.style.backgroundImage == "url('desktop.png')") {
		console.log("Start Menu Opened");
		document.getElementById('start').style.backgroundImage = "url('desktop1.png')";
	//}
	//else {
		//console.log("Start Menu Hidden");
		//document.getElementById('start').style.backgroundImage = "url('desktop.png')";
	//}	
}